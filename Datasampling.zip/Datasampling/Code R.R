# ANOVA

# Créer des données d'exemple
groupe1 <- c(25, 30, 28, 29, 27)
groupe2 <- c(35, 32, 34, 38, 33)
groupe3 <- c(22, 24, 23, 25, 21)

# Créer un vecteur pour les données
donnees <- c(groupe1, groupe2, groupe3)

# Créer un vecteur pour les groupes
groupes <- factor(rep(c("A", "B", "C"), each = 5))

# Réaliser l'ANOVA
resultat_anova <- aov(donnees ~ groupes)

# Afficher le résumé des résultats
summary(resultat_anova)
# Créer un boxplot
boxplot(donnees ~ groupes)

# Vérifier les conditions d'application
# Test de normalité
shapiro.test(residuals(resultat_anova))

# Test d'homogénéité des variances
bartlett.test(donnees ~ groupes)

#Tukey HSD
tukey <- TukeyHSD(modele_anova)

# Latin square

# Le carré latin est un plan d'expérience où chaque traitement apparaît exactement une fois 
# dans chaque ligne et dans chaque colonne, permettant de contrôler deux sources de variation.

# Installation et chargement des packages nécessaires
install.packages("agricolae")  # Package pour l'analyse des plans d'expérience
library(agricolae)

# Création des données d'exemple
# Supposons une expérience avec 4 traitements (A, B, C, D) testés sur 4 parcelles
# en tenant compte de deux facteurs de variation (lignes et colonnes)

treatments <- c("A", "B", "C", "D")  # Définition des traitements
rows <- 4                            # Nombre de lignes
columns <- 4                         # Nombre de colonnes

# Génération du plan en carré latin
set.seed(123)  # Pour la reproductibilité des résultats
latin_square <- design.lsd(treatments, rows, seed = 123)

# Affichage du plan expérimental
print("Plan expérimental en carré latin:")
print(latin_square$sketch)

# Création des données simulées pour l'exemple
# Supposons que nous mesurons le rendement d'une culture
yields <- c(45, 52, 38, 41,    # Rendements pour la ligne 1
            39, 47, 43, 38,     # Rendements pour la ligne 2
            42, 45, 36, 44,     # Rendements pour la ligne 3
            37, 40, 46, 43)     # Rendements pour la ligne 4

# Création du jeu de données complet
data <- data.frame(
  Row = factor(rep(1:4, each = 4)),          # Facteur ligne
  Column = factor(rep(1:4, times = 4)),      # Facteur colonne
  Treatment = as.vector(latin_square$sketch), # Traitements
  Yield = yields                             # Variable réponse
)

# Analyse de variance du carré latin
latin_model <- aov(Yield ~ Row + Column + Treatment, data = data)

# Affichage des résultats de l'ANOVA
print("Résultats de l'analyse de variance:")
summary(latin_model)

# Test de comparaisons multiples (Tukey HSD)
tukey_test <- TukeyHSD(latin_model, "Treatment")
print("Comparaisons multiples entre traitements:")
print(tukey_test)

# Visualisation des résultats
# Création d'un boxplot pour comparer les traitements
boxplot(Yield ~ Treatment, data = data,
        main = "Comparaison des rendements par traitement",
        xlab = "Traitement",
        ylab = "Rendement")

# Diagnostic des résidus
# Test de normalité
shapiro.test(residuals(latin_model))

# Plot des résidus
par(mfrow = c(2,2))



# RCT

# Fonction pour simuler et analyser un essai contrôlé randomisé
rct_analyse <- function(n_participants = 100, effet_traitement = 2) {
  # Définir une seed pour la reproductibilité
  set.seed(123)
  
  # Créer les données
  donnees <- data.frame(
    id = 1:n_participants,
    # Assigner aléatoirement le traitement (1) ou contrôle (0)
    groupe = sample(c(0, 1), n_participants, replace = TRUE),
    # Variable démographique (ex: âge)
    age = rnorm(n_participants, mean = 45, sd = 10)
  )
  
  # Simuler l'effet du traitement
  # La formule suppose que le traitement a un effet additif
  donnees$resultat <- 10 + 
    effet_traitement * donnees$groupe + 
    0.1 * donnees$age + 
    rnorm(n_participants, mean = 0, sd = 2)
  
  # Analyse statistique
  # Test t pour comparer les groupes
  test_t <- t.test(resultat ~ groupe, data = donnees)
  
  # Régression linéaire avec contrôle pour l'âge
  modele <- lm(resultat ~ groupe + age, data = donnees)
  
  # Résumé des résultats
  resultats <- list(
    n_traitement = sum(donnees$groupe == 1),
    n_controle = sum(donnees$groupe == 0),
    moyenne_traitement = mean(donnees$resultat[donnees$groupe == 1]),
    moyenne_controle = mean(donnees$resultat[donnees$groupe == 0]),
    test_t = test_t,
    regression = summary(modele),
    donnees = donnees
  )
  
  return(resultats)
}

# Exemple d'utilisation
resultats <- rct_analyse(n_participants = 100, effet_traitement = 2)

# Afficher les résultats principaux
print(paste("Nombre de participants dans le groupe traitement:", resultats$n_traitement))
print(paste("Nombre de participants dans le groupe contrôle:", resultats$n_controle))
print(paste("Moyenne du groupe traitement:", round(resultats$moyenne_traitement, 2)))
print(paste("Moyenne du groupe contrôle:", round(resultats$moyenne_controle, 2)))
print("\nRésultats du test t:")
print(resultats$test_t)
print("\nRésultats de la régression:")
print(resultats$regression)

# Création d'un graphique de comparaison
library(ggplot2)

ggplot(resultats$donnees, aes(x = factor(groupe), y = resultat, fill = factor(groupe))) +
  geom_boxplot() +
  labs(title = "Comparaison des résultats entre les groupes",
       x = "Groupe (0 = Contrôle, 1 = Traitement)",
       y = "Résultat") +
  scale_fill_discrete(name = "Groupe",
                      labels = c("Contrôle", "Traitement"))


plot(latin_model)