library(shiny)
library(ggplot2)
library(agricolae)
library(car)

# Interface utilisateur
ui <- fluidPage(
  titlePanel("Analyses Statistiques Expérimentales"),
  
  tabsetPanel(
    # Onglet ANOVA
    tabPanel("ANOVA",
             fluidRow(
               column(4,
                      wellPanel(
                        h3("Données d'entrée ANOVA"),
                        numericInput("groupe1_1", "Groupe A - Valeur 1:", 25),
                        numericInput("groupe1_2", "Groupe A - Valeur 2:", 30),
                        numericInput("groupe1_3", "Groupe A - Valeur 3:", 28),
                        numericInput("groupe1_4", "Groupe A - Valeur 4:", 29),
                        numericInput("groupe1_5", "Groupe A - Valeur 5:", 27),
                        hr(),
                        numericInput("groupe2_1", "Groupe B - Valeur 1:", 35),
                        numericInput("groupe2_2", "Groupe B - Valeur 2:", 32),
                        numericInput("groupe2_3", "Groupe B - Valeur 3:", 34),
                        numericInput("groupe2_4", "Groupe B - Valeur 4:", 38),
                        numericInput("groupe2_5", "Groupe B - Valeur 5:", 33),
                        hr(),
                        numericInput("groupe3_1", "Groupe C - Valeur 1:", 22),
                        numericInput("groupe3_2", "Groupe C - Valeur 2:", 24),
                        numericInput("groupe3_3", "Groupe C - Valeur 3:", 23),
                        numericInput("groupe3_4", "Groupe C - Valeur 4:", 25),
                        numericInput("groupe3_5", "Groupe C - Valeur 5:", 21),
                        actionButton("run_anova", "Exécuter l'ANOVA")
                      )
               ),
               column(8,
                      h3("Résultats ANOVA"),
                      plotOutput("anova_boxplot"),
                      verbatimTextOutput("anova_results"),
                      verbatimTextOutput("normality_test"),
                      verbatimTextOutput("variance_test"),
                      verbatimTextOutput("tukey_results")
               )
             )
    ),
    
    # Onglet Latin Square
    tabPanel("Latin Square",
             fluidRow(
               column(4,
                      wellPanel(
                        h3("Paramètres Latin Square"),
                        numericInput("ls_size", "Taille du carré (4 recommandé):", 4, min = 3, max = 5),
                        actionButton("run_ls", "Générer Latin Square")
                      )
               ),
               column(8,
                      h3("Résultats Latin Square"),
                      tableOutput("ls_design"),
                      verbatimTextOutput("ls_anova"),
                      verbatimTextOutput("ls_tukey"),
                      plotOutput("ls_boxplot")
               )
             )
    ),
    
    # Onglet RCT
    tabPanel("RCT",
             fluidRow(
               column(4,
                      wellPanel(
                        h3("Paramètres RCT"),
                        numericInput("n_participants", "Nombre de participants:", 100, min = 20, max = 1000),
                        numericInput("effect_size", "Taille de l'effet:", 2, min = 0, max = 5),
                        actionButton("run_rct", "Exécuter RCT")
                      )
               ),
               column(8,
                      h3("Résultats RCT"),
                      verbatimTextOutput("rct_summary"),
                      plotOutput("rct_plot"),
                      verbatimTextOutput("rct_tests")
               )
             )
    )
  )
)

# Serveur
server <- function(input, output) {
  
  # ANOVA
  observeEvent(input$run_anova, {
    groupe1 <- c(input$groupe1_1, input$groupe1_2, input$groupe1_3, input$groupe1_4, input$groupe1_5)
    groupe2 <- c(input$groupe2_1, input$groupe2_2, input$groupe2_3, input$groupe2_4, input$groupe2_5)
    groupe3 <- c(input$groupe3_1, input$groupe3_2, input$groupe3_3, input$groupe3_4, input$groupe3_5)
    
    donnees <- c(groupe1, groupe2, groupe3)
    groupes <- factor(rep(c("A", "B", "C"), each = 5))
    
    resultat_anova <- aov(donnees ~ groupes)
    
    output$anova_boxplot <- renderPlot({
      boxplot(donnees ~ groupes, 
              main = "Comparaison des groupes",
              xlab = "Groupes",
              ylab = "Valeurs")
    })
    
    output$anova_results <- renderPrint({
      summary(resultat_anova)
    })
    
    output$normality_test <- renderPrint({
      cat("Test de normalité (Shapiro-Wilk):\n")
      shapiro.test(residuals(resultat_anova))
    })
    
    output$variance_test <- renderPrint({
      cat("\nTest d'homogénéité des variances (Bartlett):\n")
      bartlett.test(donnees ~ groupes)
    })
    
    output$tukey_results <- renderPrint({
      cat("\nTest de Tukey HSD:\n")
      TukeyHSD(resultat_anova)
    })
  })
  
  # Latin Square
  observeEvent(input$run_ls, {
    n <- input$ls_size
    treatments <- LETTERS[1:n]
    
    # Générer le design
    ls_design <- design.lsd(treatments, n, seed = 123)
    
    # Simuler des données
    yields <- rnorm(n * n, mean = 45, sd = 5)
    
    data <- data.frame(
      Row = factor(rep(1:n, each = n)),
      Column = factor(rep(1:n, times = n)),
      Treatment = as.vector(ls_design$sketch),
      Yield = yields
    )
    
    # Analyse
    ls_model <- aov(Yield ~ Row + Column + Treatment, data = data)
    
    output$ls_design <- renderTable({
      ls_design$sketch
    })
    
    output$ls_anova <- renderPrint({
      cat("Résultats de l'ANOVA:\n")
      print(summary(ls_model))
    })
    
    output$ls_tukey <- renderPrint({
      cat("\nTest de Tukey pour les traitements:\n")
      print(TukeyHSD(ls_model, "Treatment"))
    })
    
    output$ls_boxplot <- renderPlot({
      boxplot(Yield ~ Treatment, data = data,
              main = "Rendements par traitement",
              xlab = "Traitement",
              ylab = "Rendement")
    })
  })
  
  # RCT
  observeEvent(input$run_rct, {
    resultats <- rct_analyse(input$n_participants, input$effect_size)
    
    output$rct_summary <- renderPrint({
      cat("Résumé des groupes:\n")
      cat("Groupe traitement (n =", resultats$n_traitement, "):",
          "moyenne =", round(resultats$moyenne_traitement, 2), "\n")
      cat("Groupe contrôle (n =", resultats$n_controle, "):",
          "moyenne =", round(resultats$moyenne_controle, 2), "\n")
    })
    
    output$rct_plot <- renderPlot({
      ggplot(resultats$donnees, 
             aes(x = factor(groupe), y = resultat, fill = factor(groupe))) +
        geom_boxplot() +
        labs(title = "Comparaison des résultats entre les groupes",
             x = "Groupe (0 = Contrôle, 1 = Traitement)",
             y = "Résultat") +
        scale_fill_discrete(name = "Groupe",
                            labels = c("Contrôle", "Traitement"))
    })
    
    output$rct_tests <- renderPrint({
      cat("\nRésultats du test t:\n")
      print(resultats$test_t)
      cat("\nRésultats de la régression:\n")
      print(resultats$regression)
    })
  })
}

# Lancer l'application
shinyApp(ui = ui, server = server)